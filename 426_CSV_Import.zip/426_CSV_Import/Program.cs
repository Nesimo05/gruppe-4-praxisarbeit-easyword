using System;
using System.Collections.Generic;
using System.Formats.Asn1;
using System.Globalization;
using System.IO;
using System.Linq;
using CsvHelper;
using CsvHelper.Configuration;
using CsvHelper.TypeConversion;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.DependencyInjection;

public class TranslationPair
{
    public int Id { get; set; }
    public string Language { get; set; }
    public string Word { get; set; }
}

public class TranslationContext : DbContext
{
    public DbSet<TranslationPair> Translations { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlite("Data Source=wortliste.db");
    }
}

class Program
{
    static void Main(string[] args)
    {
        string csvFilePath = "wortliste.csv"; // Pfad zur CSV-Datei anpassen

        ImportAndSaveTranslations(csvFilePath);
    }

    static void ImportAndSaveTranslations(string filePath)
    {
        try
        {
            using (var reader = new StreamReader(filePath))
            using (var csv = new CsvReader(reader, new CsvConfiguration(CultureInfo.InvariantCulture)))
            {
                csv.Context.TypeConverterOptionsCache.AddOptions<string>(new TypeConverterOptions { NullValues = { "" } });
                csv.Configuration.Delimiter = ";"; // Trennzeichen anpassen, falls erforderlich

                var records = csv.GetRecords<dynamic>().ToList();

                using (var context = new TranslationContext())
                {
                    // L�schen Sie alle vorhandenen �bersetzungen in der Datenbank
                    context.Translations.RemoveRange(context.Translations);
                    context.SaveChanges();

                    foreach (var record in records)
                    {
                        foreach (var columnName in csv.Context.HeaderRecord)
                        {
                            if (record[columnName] != null)
                            {
                                var translationPair = new TranslationPair
                                {
                                    Language = columnName,
                                    Word = record[columnName]
                                };
                                context.Translations.Add(translationPair);
                            }
                        }
                    }

                    context.SaveChanges();
                }
            }

            Console.WriteLine("�bersetzungen wurden erfolgreich importiert und in der Datenbank gespeichert.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Fehler beim Importieren und Speichern der �bersetzungen: {ex.Message}");
        }
    }
}
